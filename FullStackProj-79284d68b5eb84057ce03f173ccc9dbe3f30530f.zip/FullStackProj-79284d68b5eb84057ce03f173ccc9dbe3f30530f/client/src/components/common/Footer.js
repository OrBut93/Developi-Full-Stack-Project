import React, {Component} from 'react';

export default class Footer extends Component {

    render() {
        return (
            <footer className={"footer bg-dark w-100"}>
                © Developi
            </footer>
        );
    }
}